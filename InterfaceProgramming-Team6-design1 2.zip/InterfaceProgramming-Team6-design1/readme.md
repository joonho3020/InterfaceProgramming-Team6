# Interface Programming Final Proj Team 6 Repository

To Do
> 1. Magnify image when touched
> 2. Swipe left & right to show prev/next image (optional)
> 3. Keyword Search (done)
> 4. Ideation 
